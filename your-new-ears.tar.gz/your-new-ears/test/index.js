var test = require('tape')

test('testing your-new-ears', function (t) {
  t.ok(true)
  t.end()
})
