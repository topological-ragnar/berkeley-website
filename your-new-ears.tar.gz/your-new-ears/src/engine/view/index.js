import $ from 'jquery'

class View {
  
  closeLoadingScreen () {
    $('#loading-screen').hide()
  }

}

export default View
