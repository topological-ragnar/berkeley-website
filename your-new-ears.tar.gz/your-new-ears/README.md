## your-new-ears

Run (eg. microphone) sound through audio effects. The effects chain in represented as a 3d sound refractor reactor.



_*!!press spacebar to stop feedback loops!!*_

### install

```
git clone https://github.com/topological-ragnar/your-new-ears
cd 
npm install
```

### develop

```
npm start
```

browse to <http://localhost:9966/>.

### test

```
npm test
```

### deploy

```
npm run deploy
```
