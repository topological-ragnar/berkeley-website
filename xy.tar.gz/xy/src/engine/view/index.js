const $ = require('jquery')

class View {

  closeLoadingScreen () {
    $('#loading-screen').hide()
  }

}

module.exports = View
