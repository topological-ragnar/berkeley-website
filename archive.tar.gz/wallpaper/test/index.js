var test = require('tape')

test('testing kaleidoscopia', function (t) {
  t.ok(true)
  t.end()
})
