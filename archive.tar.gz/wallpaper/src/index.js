import Engine from './engine'

var engine = new Engine()
engine.bindEventListeners()
engine.start()
